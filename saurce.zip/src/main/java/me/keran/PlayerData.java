
package me.keran;

public class PlayerData {
    public String uuid;
    public String name;
    public boolean online;
    public boolean premium;

    public String rank;
    public String clan;
    public String money;
    public String points;
    public String prefix;

    public String kills;
    public String deaths;

    public long firstJoin;
    public long lastSeen;
}
