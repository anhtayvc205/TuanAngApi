package me.keran;

import com.google.gson.Gson;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.io.File;
import java.nio.file.Files;

public class PlayerDataService {

    private final KeranPlugin plugin;
    private final Gson gson = new Gson();

    public PlayerDataService(KeranPlugin plugin) {
        this.plugin = plugin;
    }

    public PlayerData getData(OfflinePlayer p) {
        if (p.isOnline()) {
            PlayerData d = collectOnline(p.getPlayer());
            save(p, d);
            return d;
        }

        PlayerData cached = load(p);
        if (cached != null) return cached;

        PlayerData d = new PlayerData();
        d.uuid = p.getUniqueId().toString();
        d.name = p.getName();
        d.online = false;
        d.premium = PremiumChecker.check(p.getName());
        return d;
    }

    private PlayerData collectOnline(Player p) {
        PlayerData d = new PlayerData();

        d.uuid = p.getUniqueId().toString();
        d.name = p.getName();
        d.online = true;
        d.premium = PremiumChecker.check(p.getName());

        d.rank = PlaceholderAPI.setPlaceholders(p, "%luckperms_groups%");
        d.clan = PlaceholderAPI.setPlaceholders(p, "%clanplus_clan_name%");
        d.money = PlaceholderAPI.setPlaceholders(p, "%cmi_user_balance_formatted%");
        d.points = PlaceholderAPI.setPlaceholders(p, "%playerpoints_points%");
        d.kills = PlaceholderAPI.setPlaceholders(p, "%statistic_player_kills%");
        d.deaths = PlaceholderAPI.setPlaceholders(p, "%statistic_deaths%");

        if (plugin.getConfig().getBoolean("display.show-prefix")) {
            d.prefix = PlaceholderAPI.setPlaceholders(p, "%luckperms_prefix%");
        }

        d.lastSeen = System.currentTimeMillis();

        // ===== FIX firstJoin (QUAN TRỌNG) =====
        PlayerData old = load(p);
        if (old != null && old.firstJoin > 0) {
            d.firstJoin = old.firstJoin;
        } else {
            d.firstJoin = System.currentTimeMillis();
        }

        return d;
    }

    private void save(OfflinePlayer p, PlayerData d) {
        try {
            File f = new File(plugin.getDataFolder(), "players/" + p.getUniqueId() + ".json");
            Files.writeString(f.toPath(), gson.toJson(d));
        } catch (Exception ignored) {}
    }

    private PlayerData load(OfflinePlayer p) {
        try {
            File f = new File(plugin.getDataFolder(), "players/" + p.getUniqueId() + ".json");
            if (!f.exists()) return null;
            return gson.fromJson(Files.readString(f.toPath()), PlayerData.class);
        } catch (Exception e) {
            return null;
        }
    }
}
